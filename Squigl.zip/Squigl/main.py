import pygame, sys, math, random
from settings import *
pygame.init()

score = 0

class Ink(pygame.sprite.Sprite):
  def __init__(self, x, y):
    super().__init__() 
    self.x = x
    self.y = y
    self.image = pygame.image.load('inkblotch.png').convert_alpha()
    self.rect = self.image.get_rect(topleft = (self.x,self.y))
    self.image.set_alpha(100)
    self.xspeed = random.randint(-100,100) / 75
    self.yspeed = random.randint(-100,100) / 75
    self.rotatespeed = random.randint(-100,100) / 100
    self.angle = 0
    self.age = 0
  def update(self):
    self.x += self.xspeed
    self.y += self.yspeed
    self.angle += self.rotatespeed
    self.image = pygame.transform.rotate(pygame.image.load('inkblotch.png').convert_alpha(), self.angle)
    self.rect = self.image.get_rect(topleft = (self.x,self.y))
    self.image.set_alpha(100 - self.age)
    self.age += 1

    
    

class sandBuck(pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()

    self.image =  pygame.transform.scale(pygame.image.load('sandbuck.png'), (50,50))
    self.rect = self.image.get_rect(midbottom = (random.randint(50,780),random.randint(50,780)))


class Player(pygame.sprite.Sprite):
  def __init__(self, xpos, ypos):
    super().__init__()  
    self.angle = 0
    self.image = pygame.transform.scale(pygame.image.load('Squigl.png'), (100,100))
    self.tentacleImage = pygame.transform.scale(pygame.image.load('Squigacle.png'), (30, 60))
    self.display_surface = pygame.display.get_surface()
    self.rect = self.image.get_rect()
    self.tentacleRect = self.tentacleImage.get_rect()
    self.rect.center = [xpos, ypos]
    self.xpos = xpos
    self.ypos = ypos
    self.xspeed = 0
    self.yspeed = 0
    self.friction = 0.1
    self.idle = False

  def draw(self):
    self.image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load('Squigl.png'), (100,100)), self.angle)
    self.tentacleImage = pygame.transform.rotate(pygame.transform.scale(pygame.image.load('squigacle.png'), (20, 40)), self.angle)
    self.tentacleRect.center = (self.xpos + ((-25 * math.cos(self.angle)) - (70 * math.sin(self.angle))), self.ypos + ((-25 * math.sin(self.angle)) + (70 * math.cos(self.angle))))
    self.rect.center = [self.xpos, self.ypos]
    self.display_surface.blit(self.image, self.rect)
    #self.display_surface.blit(self.tentacleImage, self.tentacleRect)
  

  def Ink_Self(self):
    if pygame.mouse.get_pressed()[2] == True:
      ink.add(Ink(self.xpos,self.ypos))
    
    
  def player_movement(self):
    self.xspeed *= 0.85
    self.yspeed *= 0.85
    if abs(self.xspeed) <= 0.1:
      self.xspeed = 0
    if abs(self.yspeed) <= 0.1:
      self.yspeed = 0

    self.xpos += self.xspeed
    self.ypos += self.yspeed

    mouse_pos = pygame.mouse.get_pos()
    if pygame.mouse.get_pressed()[0] == True:
      self.xspeed += (pygame.mouse.get_pos()[0] - self.xpos) / 100
      self.yspeed += (pygame.mouse.get_pos()[1] - self.ypos) / 100
      self.angle = (math.atan2(self.xpos-mouse_pos[0], self.ypos-mouse_pos[1]) * 57.3)
      self.idle = False
    if pygame.mouse.get_pressed()[0] == False and self.xspeed + self.yspeed <= 4:
      self.idle = True

    if self.idle == True:
      if self.angle > 180:
        self.angle += 5
      if self.angle <= 180:
        self.angle -= 5
      if self.angle <= 5 or self.angle > 360 or self.angle < 0:
        self.angle = 0

    self.draw()
  def update(self):
    self.player_movement()
    self.Ink_Self()

#Timer
#sandDollar_spawn_timer = pygame.USEREVENT + 5
#pygame.time.set_timer(sandDollar_spawn_timer,1300)

player = pygame.sprite.GroupSingle()
ink = pygame.sprite.Group()
#sandDollar = pygame.sprite.Group()

#DELETE THIS
#print(score)

def collect_sandDollar():
   global score
   if pygame.sprite.spritecollide(player,sandDollar,True):
     score = score + 10
     return False
   else: return True

class Game:
  def __init__(self):

    # general setup
    self.screen = pygame.display.set_mode((WIDTH,HEIGTH))
    self.display_surface = pygame.display.get_surface()
    pygame.display.set_caption('Squigl')
    self.clock = pygame.time.Clock()
    self.stage = 1
    self.player = Player(100,100)
    self.background = pygame.image.load('background.png')
    self.backgroundRect = self.background.get_rect()
                                 
  def run(self):
    while True:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          pygame.quit()
          sys.exit()
        #if event.type == sandDollar_spawn_timer and self.stage == 1:
          sandDollar.add(sandBuck())

        #Allows you to press space to start the game
        #if self.stage == 0:
          #keys = pygame.key.get_pressed()
          #if keys[pygame.K_SPACE]:
            #self.stage = 1 
        #elif self.stage == 1:
      self.display_surface.blit(self.background,self.backgroundRect)
      self.player.update()
      ink.update()
      for cloud in ink:
        if cloud.age >= 100:
          cloud.kill()
      ink.draw(self.screen)
      #sandDollar.draw(self.screen)
      pygame.display.update()
      self.clock.tick(FPS)
        
if __name__ == '__main__':
    game = Game()
    game.run()
