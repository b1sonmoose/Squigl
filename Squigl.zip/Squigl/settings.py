# This defines some important numbers used throughout the code

WIDTH    = 800
HEIGTH   = 800
FPS      = 60

WATERBLUE = (100,255,218)
DARKGREY = (20, 20, 20)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
